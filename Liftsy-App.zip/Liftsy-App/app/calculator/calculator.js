'use strict';

angular.module('webApp.calculator', ['ngRoute', 'firebase'])

.config(['$routeProvider', function($routeProvider){
	$routeProvider.when('/calculator', {
		templateUrl: 'calculator/calculator.html',
		controller: 'calculatorCtrl'
	});
}])

.controller('calculatorCtrl', ['$scope', '$firebaseArray', '$location', 'CommonProp', function($scope, $firebaseArray, $location, CommonProp){

	$scope.username = CommonProp.getUser();

	if(!$scope.username){
		$location.path('/home');
	}

	var ref = firebase.database().ref().child('Articles');
	$scope.Articles = $firebaseArray(ref);

	$scope.createPost = function(){
		var title = $scope.calc.titleTxt;
		var calc = $scope.calc.postTxt;
		$scope.Articles.$add({
			title: title,
			calc: calc
		}).then(function(ref){
			console.log(ref);
			$scope.success = true;
			window.setTimeout(function() {
				$scope.$apply(function(){
					$scope.success = false;
				});
			}, 2000);
		}, function(error){
			console.log(error);
		});
	};

}]);